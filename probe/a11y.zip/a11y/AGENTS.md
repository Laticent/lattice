# AGENTS.md — extend this deck with an AI agent

This folder is a portable **Marp** bundle of the "a11y" deck, exported from
Lattice. It carries the Lattice component catalog so an AI agent (Claude,
Copilot, Cursor, an SDK agent) can keep authoring the deck correctly — picking
the right layout, honoring each component's slots, and staying within its
content capacity.

## The deck

- `a11y.md` — the slides. Each opts into a Lattice **component** via a
  `<!-- _class: <name> -->` directive and fills its slots with ordinary
  Markdown. Edit this file; re-render per `README.md` (Marp — the VS Code
  extension or marp-cli).

## Pick the right component

- `agent/components.pick.md` — **start here.** One line per component: bucket,
  axes, search tags, **`capacity`** + escalation target, the components it is most
  often confused with, and a one-line purpose. The whole catalog is ~4k tokens, so skim
  or grep it to CHOOSE a layout. **Never invent a `_class` that isn't in it.**
- `agent/components.json` — the full machine-readable catalog behind it: slots,
  authoring skeleton, and `whenToUse` / `antiPatterns` / `related` prose.
  Consult it for the component you picked; at ~95k tokens it is not a document to read
  end to end.
- **Count first, then filter by capacity.** A layout overflows when it holds
  more elements than it's built for — the most common authoring slip. Before
  choosing a `_class`, count your content (items / rows / columns / code lines)
  and check the component's `capacity` `{ axis, sweet, soft, hard, escalateTo }`:
  `sweet` is ideal, past `soft` it crowds, past `hard` it overflows. Over
  `hard`? Take an `escalateTo` target or split across slides. Not every
  component declares `capacity` yet; where it's absent, judge by the skeleton
  and split when a slide looks crowded.

## Rules agents most often break

- **Card-style layouts use nested bullets, not inline bold:** `- Title` then
  `  - body`, never `- **Title.** body`.
- **Slots + skeletons in the catalog are the contract** — follow the selectors;
  don't improvise structure.
- **No new `$…$` math here.** The equations are typeset at export and Marp's
  math is off in this bundle (it can run code hidden in a formula), so new TeX
  shows as text. Write it in the Lattice source and re-export. Keep a prose
  dollar escaped as `\$`.

## Provenance

The catalog is a **frozen snapshot** taken when this deck was exported
(Lattice 1.0.0). It reflects the components available then; a newer Lattice may add
more. Re-export from Lattice to refresh it.
