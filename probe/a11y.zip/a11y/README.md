# a11y

This folder is a Lattice deck packaged for **Marp**. Everything it needs is already in
here: the slides, the `a11y-deuteranopia` theme, the fonts, and the small scripts that draw its
diagrams and charts. You do not install a theme or edit any settings by hand.

You can work with it two ways, and they produce the same result:

- **In VS Code**, to edit the slides with a live preview and export from the editor.
- **From the command line**, with marp-cli, to export in one command.

## What you need

| For | Install |
|---|---|
| Editing and previewing | [Visual Studio Code](https://code.visualstudio.com). It offers the Marp extension for you in step 3. |
| Exporting a PDF, PowerPoint or image, on either route | Google Chrome or Microsoft Edge. Marp drives the browser in the background; you will not see a window. (Marp can also use Firefox; this bundle was tested with Chrome.) |
| The command line, or VS Code's export tasks | [Node.js](https://nodejs.org) 18 or later. |

## Quick start: VS Code

1. **Open this folder.** If it came as a zip, unzip it first. In VS Code, choose **File → Open Folder…** and pick
   the folder that contains this README. Open this folder itself, not a folder above it:
   the theme settings in `.vscode/` only apply when this is the folder you opened. (The
   first time VS Code ever runs, a *Welcome to VS Code* window comes first; click
   **Continue without Signing In**, then **Get Started**.)
2. **Trust the folder.** VS Code opens a new folder in **Restricted Mode**: a banner at
   the top says *"Restricted Mode is intended for safe code browsing"*, and the bottom-left
   corner reads *Restricted Mode*. Click **Manage** in the banner, then **Trust**. Until you
   do, VS Code ignores the folder's theme settings and will not run its export tasks. (If
   VS Code instead asks *"Do you trust the authors of the files in this folder?"*, choose
   **Yes, I trust the authors**.)
3. **Install Marp for VS Code.** A notification asks *"Do you want to install the
   recommended 'Marp for VS Code' extension from Marp team for this repository?"* Click
   **Install**, then **Trust Publisher & Install**. Missed it? Open the Extensions view
   (Ctrl+Shift+X, or Cmd+Shift+X on macOS), search for **Marp for VS Code**, and install it.
4. **Open the deck.** Click `a11y.md` in the Explorer.
5. **Open the preview.** Click **Open Preview to the Side** at the top right of the editor,
   or press Ctrl+K then V (Cmd+K then V on macOS).
6. **Let the deck draw its diagrams and charts.** The preview first shows *"Some content
   has been disabled in this document"*, and the slides that need drawing look unfinished.
   Click that message and choose **Disable** (*"Allow all content and script execution"*).
   VS Code remembers the choice for this folder. The scripts it allows are the deck's own
   bundled renderers; Lattice removed every other script from the deck when it exported.
7. **Export.** Click in the editor that shows `a11y.md` (not the preview), then click
   the Marp icon at its top right (*Show Quick Pick Of Marp Commands*) and choose **Export
   Slide Deck…**. In the save dialog, end the file name with the format you want:
   `.pdf`, `.pptx` or `.html`. **The name decides the format**; the file-type list
   in the dialog only filters what it shows, so choosing *HTML* there and keeping the name
   `a11y.pdf` still saves a PDF. (`.png` and `.jpeg` save the first slide only.)
   Or choose **Terminal → Run Task…** and pick **Marp: export PDF**, **Marp: export
   PowerPoint** or **Marp: export HTML** (the list also shows tasks other tools offer;
   pick one that starts with *Marp:*). Each task first runs `npm install`. The first time,
   that downloads marp-cli, which takes a few seconds; after that it finishes at once, even
   offline. Both routes give the same result.

Edit `a11y.md` and the preview updates as you type.

## Quick start: command line

In a terminal, in this folder:

```sh
npm install       # once: installs marp-cli, the only dependency
npm run pdf       # → a11y.pdf
npm run pptx      # → a11y.pptx
npm run html      # → a11y.html
```

To export without installing anything into the folder:

```sh
npx @marp-team/marp-cli@4 a11y.md --config-file marp.config.cjs --allow-local-files -o a11y.pdf
```

Always pass `--config-file marp.config.cjs`. It registers the theme and lists the HTML
the deck may use. Do **not** add `--html`: that replaces the list with "everything".
Each export prints *"WARN Insecure local file accessing is enabled"*. That is expected:
`--allow-local-files` lets the browser read the fonts and images in this folder.

## What each export gives you

- **PDF**: the complete deck, one page per slide. The one to share.
- **PowerPoint**: the complete deck, one picture per slide. It looks the same, but you
  cannot edit the text in PowerPoint; edit `a11y.md` and export again.
- **HTML**: opens in a browser and draws the deck there, so it needs the scripts and
  fonts in this folder next to it. Opened here, it is complete. Moved on its own, its
  diagrams and charts disappear; to share it, send the whole folder as a zip.
- **The VS Code preview**: complete once you allow scripts in step 6. Use it to write;
  export to check the final slides.

## If something looks wrong

| You see | Do this |
|---|---|
| Plain slides: system fonts, no colors, no layout | You opened a folder above this one, or the folder is not trusted. Open this folder itself (step 1) and trust it (step 2). |
| An export came out as a PDF when you wanted another format | The file name decides the format. Export again and end the name with `.pptx` or `.html` (step 7). |
| *"The specified theme … is not recognized by Marp for VS Code"* | The deck was opened before the folder was trusted. Trust it (step 2), then close the deck and open it again. |
| Diagrams or charts missing in the preview, or the banner *"Some content has been disabled"* | Allow scripts (step 6). |
| HTML tags like `<div>` or `<script>` printed on the slides in VS Code | The folder is not trusted: trust it (step 2). If it is trusted, your Marp for VS Code is older than 3.0; update it in the Extensions view. |
| Fractions and superscripts collapsed onto one line, or `<svg` printed inside an equation, in VS Code | The folder is not trusted. Trust it (step 2). |
| *"No suitable browser found"* | Install Chrome or Edge. If one is installed somewhere unusual, point Marp at it: on the command line, set the `CHROME_PATH` environment variable to its path; in VS Code, set **Markdown › Marp: Browser Path** (`markdown.marp.browserPath`) in Settings. |
| *"No usable sandbox!"* when exporting on Linux | On the command line, run the export with `CHROME_NO_SANDBOX=1` set (for example `CHROME_NO_SANDBOX=1 npm run pdf`). In VS Code, quit it and start it from a terminal where that variable is set. |
| A task does nothing, or VS Code says tasks are not allowed | Trust the folder (step 2). |
| `npm: command not found` | Install Node.js 18 or later. |
| An HTML file with no diagrams or charts | It was moved out of this folder. Open the copy in this folder, or send the folder as a zip. |

## Editing the deck

Edit `a11y.md` and export again. That works for slides, prose, and per-slide
`<!-- _class: … -->` directives.

**The front matter at the top is the exception.** Marp ignores Lattice's deck-wide
settings there (`color-mode:`, `class:`, `logo:`, `meta:`, `finish:`, …), so they
travel in a generated settings block at the end of the file. Changing them at the top has
no effect: edit that block to match, or re-export from Lattice.

**Equations are the other exception.** Lattice typeset each one when it exported, because
Marp's own math typesetter can run code hidden in a formula, so it is switched off here.
The TeX stays readable inside each equation's `<annotation>`; to change an equation,
edit the source deck and re-export. A dollar sign in prose, and in a `header:` or
`footer:`, is written `\$` for the same reason.

### If a slide overflows

A slide whose content was taller than the frame is **clipped**: the extra content is not
scrollable and is not printed. Trimming it, or moving it to a layout with more room, is
the only fix.

Rather than lose it quietly, this deck tags such a slide **"Content clipped"** along its bottom edge.

Re-export from Lattice to change that — `--overflow-marker=author` for the full editing signal (a red ring and per-cell "Fix Me" tags), or `--overflow-marker=off` for no marker at all. Without Lattice to hand, edit the `overflowMarker` value in the generated settings block at the end of the deck.

### What Marp renders differently from Lattice

Some Lattice features are built while the deck is parsed, earlier than any Marp tool lets
a plugin in, and some come from code that a Marp render never runs. Each one falls back to
something readable:

| What you authored | What a Marp render gives you |
|---|---|
| a panes slide (`<!-- pane: X -->`): two components side by side or stacked on one slide | Marp cannot lay out two components on one slide, so both panes' content is stacked, and a slide Lattice would split into one slide per pane stays one slide. The export drops the pane markers (Marp would show them as speaker notes), so this deck opened in Lattice again keeps its panes' content but not their layout |
| a `_focusSteps` slide — one cloned slide per step | stays one slide; the directive rides along as an inert comment |
| the mark on a backslash-escaped arrow character (`\->`, `\&`) that a flowchart reads as text | the character shows as typed; a flowchart there reads an escaped `->` as an arrow |
| a `no-period` heading — the trailing period removed | the period the author typed stays visible |
| a `with-period` heading — a trailing period added | no period is added |
| an ordered list that starts past 1 — a counter layout continues its number | a counter layout (list-steps, q-and-a) numbers from 01 again |
| a `functionplot` fence — the plotted SVG | renders as a code block showing its JSON config |
| an `anima` fence — the composed scene | renders as a code block showing its JSON scene |
| line numbers, focus, marks, diff bands, a title and wrapping on one block | the block renders as a plain highlighted code block; the record line itself is removed so it does not print as text |
| an installed code package's transform (a component someone else wrote) | A code package runs only in a sandbox after its user approved its code (the CLI's locked Chromium page; contract note 2026-09-24 §9), and a Marp render has no sandbox and no approval, so it never runs one: the slide renders as the component's CSS draws the authored content. A Marp export carries no code packages at all (portable-packages §4: an export carries the user's packages as data). |
| a data plugin's fence (a `render.js` someone else wrote, run by the fence door) | A plugin fence runs only in a sandbox after its user approved the code (plugin-system §9 decisions 3 and 14), and a Marp render has no sandbox and no approval, so it never runs one: the fence renders as the code block the engine writes for any fence. A Marp export carries no plugin code (§4.11). |

Outside that list, the theme, the typography, the diagrams, the charts and every
component layout we have rendered through Marp come out the same. If a slide looks wrong
here and right in Lattice, it is a bug worth reporting.

## Extend it with an AI agent

This folder carries the Lattice component catalog, so an AI coding agent (Claude,
Copilot, Cursor, …) can keep authoring the deck correctly. Open this folder with your
agent and point it at `AGENTS.md`: it explains how to pick a component, honor its
slots, and stay within each layout's content **capacity**, so added slides don't
overflow.

## What's in here

| Path | What it is |
|---|---|
| `a11y.md` | The deck. Edit this. |
| `lattice.css` | The Lattice layout stylesheet. |
| `themes/` | The `a11y-deuteranopia` theme (+ dark) and every theme it builds on. |
| `fonts/` | The typefaces. Keep them beside `lattice.css`, or the type falls back silently. |
| `lattice-runtime-min.js`, `lattice-dagre-min.js`, `mermaid-v11-min.js` | Draw the diagrams, charts and structural layouts in the browser. |
| `lattice-plugin-icons.js`, `lattice-plugin-avatars.js` | Icon and avatar drawings, loaded when a slide uses one. |
| `.vscode/settings.json` | Registers the theme (lattice.css, themes/onyx.css, themes/a11y-base.css, themes/a11y-deuteranopia.css) and turns on HTML for Marp for VS Code. |
| `.vscode/extensions.json` | Makes VS Code offer to install Marp for VS Code (step 3). |
| `.vscode/tasks.json` | The **Marp: export …** tasks under Terminal → Run Task…. |
| `marp.config.cjs` | The marp-cli settings: the theme and the HTML the deck may use. |
| `package.json` | Pins marp-cli and defines `npm run pdf`, `pptx` and `html`. |
| `AGENTS.md`, `agent/` | The entry point and component catalog for an AI agent. |
| `assets/` | The images the deck uses, if any. |
